
import java.io.FileWriter;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Message {

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;

    private static int totalMessagesSent = 0;

    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {
        Random random = new Random();
        long number = 1000000000L
                + (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    // Check that the message ID has no more than 10 characters
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Check the recipient's cellphone number
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+27\\d{9}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Check whether the recipient number is valid
    public boolean isRecipientValid() {
        return recipient != null && recipient.matches("^\\+27\\d{9}$");
    }

    // Check the message length
    public String checkMessageLength() {
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageText.length() - 250;

            return "Message exceeds 250 characters by "
                    + excess + "; please reduce the size.";
        }
    }

    // Create the message hash
    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1]
                .replaceAll("[^A-Za-z0-9]", "");

        String firstTwoDigits = messageID.substring(0, 2);

        return (firstTwoDigits + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // Choose whether to send, disregard or store a message
    public String SentMessage(int option) {
        switch (option) {
            case 1 -> {
                totalMessagesSent++;
                return "Message successfully sent.";
            }
            case 2 -> {
                return "Press 0 to delete the message.";
            }
            case 3 -> {
                return storeMessage();
            }
            default -> {
                return "Invalid option.";
            }
        }
    }

    // Store a message in a JSON file
    public String storeMessage() {
        try (FileWriter writer = new FileWriter("messages.json", true)) {

            writer.write("{"
                    + "\"messageID\":\"" + messageID + "\","
                    + "\"messageHash\":\"" + createMessageHash() + "\","
                    + "\"recipient\":\"" + recipient + "\","
                    + "\"message\":\""
                    + messageText.replace("\\", "\\\\")
                            .replace("\"", "\\\"")
                            .replace("\n", "\\n")
                            .replace("\r", "\\r")
                    + "\""
                    + "}\n");

            return "Message successfully stored.";

        } catch (IOException e) {
            return "Error storing message.";
        }
    }

    // Display the message details
    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + createMessageHash()
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    // Return the total number of messages sent
    public int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Getters for accessing message details
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public int getMessageNumber() {
        return messageNumber;
    }
}
    


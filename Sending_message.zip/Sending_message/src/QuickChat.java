/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class QuickChat {
   

    private final Scanner input = new Scanner(System.in);
    private final List<Message> sentMessages = new ArrayList<>();

    public void start() {

        System.out.println("Welcome to QuickChat.");

        System.out.print("How many messages would you like to enter? ");
        int numberOfMessages = input.nextInt();
        input.nextLine();

        int messagesCreated = 0;

        OUTER:
        while (true) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Enter your choice: ");
            int choice = input.nextInt();
            input.nextLine();
            switch (choice) {
                case 1 -> {
                    if (messagesCreated >= numberOfMessages) {
                        System.out.println(
                                "You have reached your selected message limit.");
                        continue;
                    }   System.out.print("Enter recipient cellphone number: ");
                    String recipient = input.nextLine();
                    System.out.print("Enter your message: ");
                    String text = input.nextLine();
                    Message message = new Message(
                            messagesCreated, recipient, text);
                    if (!message.isRecipientValid()) {
                        System.out.println(message.checkRecipientCell());
                        continue;
                    }   if (text.length() > 250) {
                        System.out.println(message.checkMessageLength());
                        continue;
                    }   System.out.println(message.checkMessageLength());
                    System.out.println("\n" + message.printMessages());
                    System.out.println("\nChoose an action:");
                    System.out.println("1) Send Message");
                    System.out.println("2) Disregard Message");
                    System.out.println("3) Store Message to send later");
                    System.out.print("Enter your choice: ");
                    int action = input.nextInt();
                    input.nextLine();
                switch (action) {
                    case 1 -> {
                        System.out.println(message.SentMessage(1));
                        sentMessages.add(message);
                        messagesCreated++;
                    }
                    case 2 -> {
                        System.out.println(message.SentMessage(2));
                        System.out.println("Message disregarded.");
                        messagesCreated++;
                    }
                    case 3 -> {
                        System.out.println(message.SentMessage(3));
                        messagesCreated++;
                    }
                    default -> System.out.println("Invalid option.");
                }
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> {
                    System.out.println("Total messages sent: "
                            + sentMessages.size());
                    System.out.println("Goodbye!");
                    break OUTER;
                }
                default -> System.out.println("Invalid choice. Please choose 1, 2 or 3.");
            }
        }
    }
}
    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
    public class Login {

    private final String username;
    private final String password;
    private final String cellPhoneNumber;

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // Check username
    public boolean checkUserName() {

        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }


    // Check password complexity
    public boolean checkPasswordComplexity() {

        if (password == null) {
            return false;
        }

        boolean hasCorrectLength = password.length() >= 8;
        boolean hasCapitalLetter = password.matches(".*[A-Z].*");
        boolean hasNumber = password.matches(".*[0-9].*");
        boolean hasSpecialCharacter =
                password.matches(".*[^a-zA-Z0-9].*");

        return hasCorrectLength
                && hasCapitalLetter
                && hasNumber
                && hasSpecialCharacter;
    }


    // Check cell phone number
    public boolean checkCellPhoneNumber() {

        if (cellPhoneNumber == null) {
            return false;
        }

        // South African international format
        return cellPhoneNumber.matches("^\\+27[0-9]{9}$");
    }


    // Registration messages
    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted; please ensure "
                    + "that your username contains an underscore and is "
                    + "no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted; please ensure "
                    + "that the password contains at least eight characters, "
                    + "a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {

            return "Cell number is incorrectly formatted or does not "
                    + "contain an international code; please correct the "
                    + "number and try again.";
        }

        return "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell number successfully captured.";
    }


    // Check login details
    public boolean loginUser(String enteredUsername,
            String enteredPassword) {

        if (enteredUsername == null || enteredPassword == null) {
            return false;
        }

        return username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }


    // Return login message
    public String returnLoginStatus(boolean loginSuccessful,
            String firstName, String lastName) {

        if (loginSuccessful) {

            return "Welcome " + firstName + ", " + lastName
                    + " it is great to see you.";
        }

        return "Username or password incorrect, please try again.";
    }
}
    


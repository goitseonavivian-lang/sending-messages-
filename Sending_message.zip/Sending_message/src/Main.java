/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import javax.swing.JOptionPane;
public class Main {

    private static QuickChat quickChat;
    private static String loginMessage;
   

    public static void main(String[] args) {

        // Get registration details
        String username = JOptionPane.showInputDialog(
                "Enter your username:"
        );

        if (username == null) {
            return;
        }

        String password = JOptionPane.showInputDialog(
                "Enter your password:"
        );

        if (password == null) {
            return;
        }

        String cellPhoneNumber;
        cellPhoneNumber = JOptionPane.showInputDialog("""
                                                      Enter your South African cell phone number:
                                                      Example: +27838968976""");

        if (cellPhoneNumber == null) {
            return;
        }


        // Create Login object
        Login user = new Login(
                username,
                password,
                cellPhoneNumber
        );


        // Display registration result
        JOptionPane.showMessageDialog(
                null,
                user.registerUser()
        );


        // Continue only when registration is valid
        if (user.checkUserName()
                && user.checkPasswordComplexity()
                && user.checkCellPhoneNumber()) {


            String firstName = JOptionPane.showInputDialog(
                    "Enter your first name:"
            );

            if (firstName == null) {
                return;
            }


            String lastName = JOptionPane.showInputDialog(
                    "Enter your last name:"
            );

            if (lastName == null) {
                return;
            }


            // Login
            String enteredUsername = JOptionPane.showInputDialog(
                    "LOGIN\n\nEnter your username:"
            );

            if (enteredUsername == null) {
                return;
            }


            String enteredPassword = JOptionPane.showInputDialog(
                    "Enter your password:"
            );

            if (enteredPassword == null) {
                return;
            }


            // Check login
            boolean loginSuccessful =
                    user.loginUser(
                            enteredUsername,
                            enteredPassword
                    );
           


            // Display login status 
            // Display login status
String loginMessage =
        user.returnLoginStatus(
                loginSuccessful,
                firstName,
                lastName
        );

System.out.println(loginMessage);

if (loginSuccessful) {
    System.out.println("Opening QuickChat...");

    QuickChat quickChat = new QuickChat();
    quickChat.start();
}

System.out.println(loginMessage);

// Start QuickChat only after successful login
if (loginSuccessful) {
    QuickChat quickChat = new QuickChat();
    quickChat.start();
}


            JOptionPane.showMessageDialog(
                    null,
                    loginMessage
            );
        }
    }
}

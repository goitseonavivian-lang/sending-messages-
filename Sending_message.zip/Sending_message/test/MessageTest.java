/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    @Test
    public void testMessageID() {
        Message message = new Message(
                0, "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    @Test
    public void testValidRecipient() {
        Message message = new Message(
                0, "+27718693002", "Hello");

        assertEquals(
                "Cell phone number successfully captured.",
                message.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipient() {
        Message message = new Message(
                1, "08575975889", "Hello");

        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message.checkRecipientCell());
    }

    @Test
    public void testMessageWithin250Characters() {
        Message message = new Message(
                0, "+27718693002", "Hello");

        assertEquals(
                "Message ready to send.",
                message.checkMessageLength());
    }

    @Test
    public void testMessageExceeds250Characters() {
        String longMessage = new String(new char[260])
                .replace('\0', 'a');

        Message message = new Message(
                0, "+27718693002", longMessage);

        assertEquals(
                "Message exceeds 250 characters by 10; please reduce the size.",
                message.checkMessageLength());
    }

    @Test
    public void testMessageHash() {
        Message message = new Message(
                0, "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertTrue(message.createMessageHash()
                .matches("\\d{2}:0:HITONIGHT"));
    }

    @Test
    public void testSendMessage() {
        Message message = new Message(
                0, "+27718693002", "Hello");

        assertEquals(
                "Message successfully sent.",
                message.SentMessage(1));
    }

    @Test
    public void testDisregardMessage() {
        Message message = new Message(
                0, "+27718693002", "Hello");

        assertEquals(
                "Press 0 to delete the message.",
                message.SentMessage(2));
    }

    @Test
    public void testStoreMessage() {
        Message message = new Message(
                0, "+27718693002", "Hello");

        assertEquals(
                "Message successfully stored.",
                message.SentMessage(3));
    }
}
    


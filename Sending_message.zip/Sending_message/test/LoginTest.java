import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import org.junit.Test;

public class LoginTest {

    @Test
    public void testUsernameCorrectlyFormatted() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkUserName());
    }


    @Test
    public void testUsernameIncorrectlyFormatted() {

        Login user = new Login(
                "kyle!!!!!",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertFalse(user.checkUserName());
    }


    @Test
    public void testPasswordCorrectlyFormatted() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkPasswordComplexity());
    }


    @Test
    public void testPasswordIncorrectlyFormatted() {

        Login user = new Login(
                "kyl_1",
                "password",
                "+27838968976"
        );

        assertFalse(user.checkPasswordComplexity());
    }


    @Test
    public void testCellPhoneCorrectlyFormatted() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkCellPhoneNumber());
    }


    @Test
    public void testCellPhoneIncorrectlyFormatted() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "0896653"
        );

        assertFalse(user.checkCellPhoneNumber());
    }


    @Test
    public void testLoginSuccessful() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertTrue(user.loginUser(
                "kyl_1",
                "Ch&&sec@ke99!"
        ));
    }


    @Test
    public void testLoginFailed() {

        Login user = new Login(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976"
        );

        assertFalse(user.loginUser(
                "wrongUser",
                "wrongPassword"
        ));
    }
}